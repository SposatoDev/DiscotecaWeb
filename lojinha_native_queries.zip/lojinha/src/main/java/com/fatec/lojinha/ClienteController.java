package com.fatec.lojinha;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonProperty;

@RestController
@CrossOrigin(origins = "*")
public class ClienteController {
    @Autowired
    ClienteRepository bd;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @GetMapping("/api/cliente/{codigo}")
    public ResponseEntity<Cliente> retorna(@PathVariable("codigo") int id) {
        return bd.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/api/cliente")
    public ResponseEntity<?> gravar(@RequestBody Cliente obj) {
        // Senhas novas são armazenadas como hash, nunca em texto puro.
        if (obj.getSenha() == null || obj.getSenha().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "A senha é obrigatória."));
        }
        obj.setCodigo(0);
        obj.setSenha(passwordEncoder.encode(obj.getSenha()));
        Cliente salvo = bd.save(obj);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("mensagem", "Cliente gravado com sucesso!", "codigo", salvo.getCodigo()));
    }

    @PutMapping("/api/cliente")
    public ResponseEntity<?> alterar(@RequestBody Cliente obj) {
        Optional<Cliente> existente = bd.findById(obj.getCodigo());
        if (existente.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("mensagem", "Cliente não encontrado."));
        }

        Cliente atual = existente.get();
        atual.setNome(obj.getNome());
        atual.setTelefone(obj.getTelefone());
        atual.setDocumento(obj.getDocumento());
        atual.setLogradouro(obj.getLogradouro());
        atual.setEmail(obj.getEmail());
        atual.setAtivo(obj.getAtivo());

        // Só altera a senha quando uma nova senha foi informada.
        if (obj.getSenha() != null && !obj.getSenha().isBlank()) {
            atual.setSenha(passwordEncoder.encode(obj.getSenha()));
        }

        bd.save(atual);
        return ResponseEntity.ok(Map.of("mensagem", "Cliente alterado com sucesso!"));
    }

    @DeleteMapping("/api/cliente/{codigo}")
    public ResponseEntity<?> apagar(@PathVariable("codigo") int id) {
        if (!bd.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        bd.deleteById(id);
        return ResponseEntity.ok(Map.of("mensagem", "Cliente removido com sucesso!"));
    }

    // POST /api/cliente/login
    @PostMapping("/api/cliente/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest dados) {
        if (dados.email() == null || dados.senha() == null) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Informe e-mail e senha."));
        }

        Optional<Cliente> resultado = bd.buscarPorEmail(dados.email());
        if (resultado.isEmpty()
                || resultado.get().getSenha() == null
                || !passwordEncoder.matches(dados.senha(), resultado.get().getSenha())
                || resultado.get().getAtivo() != 1) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("mensagem", "E-mail ou senha inválidos."));
        }

        Cliente cliente = resultado.get();
        // Não devolve a entidade completa nem o hash da senha.
        return ResponseEntity.ok(Map.of(
                "mensagem", "Login realizado com sucesso.",
                "codigo", cliente.getCodigo(),
                "nome", cliente.getNome(),
                "email", cliente.getEmail()
        ));
    }

    // POST /api/cliente/reenvio-senha
    // A consulta é nativa; o envio real exige configurar um serviço de e-mail (SMTP).
    @PostMapping("/api/cliente/reenvio-senha")
    public ResponseEntity<?> reenvioSenha(@RequestBody ReenvioSenhaRequest dados) {
        if (dados.email() == null || dados.email().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("mensagem", "Informe o e-mail cadastrado."));
        }

        // Resposta genérica para não revelar se um e-mail está cadastrado.
        if (bd.existeEmail(dados.email())) {
            // Ponto de integração: enviar e-mail com link/token de redefinição usando SMTP.
            // Por segurança, não enviamos nem retornamos a senha armazenada.
        }

        return ResponseEntity.ok(Map.of(
                "mensagem",
                "Se o e-mail estiver cadastrado, você receberá instruções para redefinir a senha."
        ));
    }

    public record LoginRequest(String email, String senha) {}
    public record ReenvioSenhaRequest(String email) {}
}
