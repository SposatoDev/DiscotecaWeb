package com.fatec.lojinha;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Integer> {

    // Native query: busca o cliente pelo e-mail informado no login.
    @Query(value = "SELECT * FROM cliente WHERE email = :email LIMIT 1", nativeQuery = true)
    Optional<Cliente> buscarPorEmail(@Param("email") String email);

    // Native query usada para verificar se o e-mail existe no pedido de recuperação.
    @Query(value = "SELECT COUNT(*) > 0 FROM cliente WHERE email = :email", nativeQuery = true)
    boolean existeEmail(@Param("email") String email);
}
