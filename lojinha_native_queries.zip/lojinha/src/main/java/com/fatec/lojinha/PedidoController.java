package com.fatec.lojinha;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class PedidoController {
    @Autowired
    PedidoRepository bd;

    @GetMapping("/api/pedido/{codigo}")
    public ResponseEntity<Pedido> retorna(@PathVariable("codigo") int id) {
        return bd.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // GET /api/pedido/cliente/{codigoCliente}
    @GetMapping("/api/pedido/cliente/{codigoCliente}")
    public ResponseEntity<?> listarPedidosPorCliente(@PathVariable int codigoCliente) {
        return ResponseEntity.ok(bd.listarPedidosPorCliente(codigoCliente));
    }

    @PostMapping("/api/pedido")
    public String gravar(@RequestBody Pedido obj) {
        bd.save(obj);
        return "Pedido gravado com sucesso! " + obj.getCodigoPedido();
    }

    @PutMapping("/api/pedido")
    public ResponseEntity<?> alterar(@RequestBody Pedido obj) {
        if (bd.existsById(obj.getCodigoPedido())) {
            bd.save(obj);
            return ResponseEntity.ok(Map.of("mensagem", "Pedido alterado com sucesso!"));
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/api/pedido/{codigo}")
    public ResponseEntity<?> apagar(@PathVariable("codigo") int id) {
        if (!bd.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        bd.deleteById(id);
        return ResponseEntity.ok(Map.of("mensagem", "Pedido removido com sucesso!"));
    }
}
